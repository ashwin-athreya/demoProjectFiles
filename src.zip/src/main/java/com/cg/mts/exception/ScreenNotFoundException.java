package com.cg.mts.exception;

public class ScreenNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ScreenNotFoundException(String msg) {
		super(msg);
	}
}
